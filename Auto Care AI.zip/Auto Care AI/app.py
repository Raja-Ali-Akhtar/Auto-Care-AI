import os
import time
import requests
from flask import Flask, render_template, request, url_for
from werkzeug.utils import secure_filename
from inference_sdk import InferenceHTTPClient
from PIL import Image, ImageDraw
from shapely.geometry import Polygon
from flask_executor import Executor
from flask_caching import Cache  # Updated import

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = './static/uploads'
app.config['PROCESSED_FOLDER'] = './static/processed'

# Cache configuration (simple cache for now)
app.config['CACHE_TYPE'] = 'simple'
cache = Cache(app)

# Executor configuration (for background tasks)
executor = Executor(app)

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['PROCESSED_FOLDER'], exist_ok=True)

DAMAGE_CLIENT = InferenceHTTPClient(api_url="https://detect.roboflow.com", api_key="x4GqQ1Icif9iqC6c703m")
LOCALITY_CLIENT = InferenceHTTPClient(api_url="https://detect.roboflow.com", api_key="haFKo8MxrbCGAN839WXu")

# Increased damage weights (multiplied by 2 for more emphasis)
damage_weights = {
    'crack': 6,         # Increased from 3
    'dent': 10,         # Increased from 5
    'glass shatter': 12, # Increased from 6
    'lamp broken': 10,   # Increased from 5
    'scratch': 4,       # Increased from 2
    'tire flat': 8      # Increased from 4
}

# Increased part weights (multiplied by 2 for more emphasis)
part_weights = {
    'Back-bumper': 6,    # Increased from 3
    'Back-door': 8,      # Increased from 4
    'Back-wheel': 6,     # Increased from 3
    'Back-window': 6,    # Increased from 3
    'Back-windshield': 10, # Increased from 5
    'Fender': 6,         # Increased from 3
    'Front-bumper': 6,   # Increased from 3
    'Front-door': 8,     # Increased from 4
    'Front-wheel': 6,    # Increased from 3
    'Front-window': 10,  # Increased from 5
    'Grille': 4,         # Increased from 2
    'Headlight': 8,      # Increased from 4
    'Hood': 6,           # Increased from 3
    'License-plate': 4,  # Increased from 2
    'Mirror': 4,         # Increased from 2
    'Quarter-panel': 6,  # Increased from 3
    'Rocker-panel': 6,   # Increased from 3
    'Roof': 4,           # Increased from 2
    'Tail-light': 4,     # Increased from 2
    'Trunk': 4,          # Increased from 2
    'Windshield': 10     # Increased from 5
}


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        sides = ['front', 'back', 'left', 'right']
        results, ratings, collective_damage = [], [], []
        final_damaged_parts = set()  # Set to store unique damaged parts

        # Process each side asynchronously
        futures = []
        for side in sides:
            file = request.files.get(side)
            if not file or file.filename == '':
                return f"No file uploaded for {side}", 400

            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)

            # Asynchronously process the image for each side
            future = executor.submit(process_image, file_path, side)
            futures.append(future)

        # Collect results from all futures
        for future in futures:
            img_url, damages, rating, damaged_parts = future.result()
            results.append({'side': side.capitalize(), 'image_url': img_url, 'damage_info': damages, 'health_rating': rating})
            collective_damage.extend(damages)
            ratings.append(rating)

            # Add the damaged parts to the final set (to avoid duplicates)
            final_damaged_parts.update(damaged_parts)

        # Apply a weight for the lowest ratings without drastically altering the formula
        min_rating = min(ratings)
        weighted_ratings = [rating + (min_rating - rating) * 0.5 for rating in ratings]  # Apply 50% weight for the lowest ratings

        final_rating = round(sum(weighted_ratings) / len(weighted_ratings), 2)  # Calculate the weighted average

        print("Final Damaged Parts:", list(final_damaged_parts))  # Print unique damaged parts from all sides

        # Pass final_damaged_parts to the template
        return render_template('index.html', results=results, collective_damage=collective_damage, final_rating=final_rating, final_damaged_parts=final_damaged_parts)


    return render_template('index.html', results=None)


@cache.memoize(timeout=60 * 60)  # Cache the image processing results for 1 hour
def process_image(file_path, side):
    retries = 3  # Retry mechanism for inference
    for attempt in range(retries):
        try:
            # Attempt inference with retries
            loc_preds = LOCALITY_CLIENT.infer(file_path, model_id="carpartsdetect/1")['predictions']
            break  # If successful, exit the loop
        except requests.exceptions.Timeout as e:
            print(f"Request timeout error: {e}. Retrying... ({attempt + 1}/{retries})")
            time.sleep(2)  # Wait before retrying
        except Exception as e:
            print(f"Error occurred during inference: {e}")
            return "", [], 0, []  # Return empty results in case of error

    # Process the image with the inference results
    dmg_preds = DAMAGE_CLIENT.infer(file_path, model_id="hi-xg1ga/2")['predictions']
    img = Image.open(file_path).convert("RGBA")
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)

    damage_info, total_score = [], 0
    damaged_parts = []  # List to store damaged parts only

    for dmg in [d for d in dmg_preds if d['confidence'] >= 0.3]:
        d_poly = Polygon([(p['x'], p['y']) for p in dmg['points']])
        d_weight = damage_weights.get(dmg['class'], 1)

        if not d_poly.is_valid:
            d_poly = d_poly.buffer(0)

        for loc in [l for l in loc_preds if l['confidence'] >= 0.6]:
            l_poly = Polygon([(p['x'], p['y']) for p in loc['points']])

            if not l_poly.is_valid:
                l_poly = l_poly.buffer(0)

            if d_poly.intersects(l_poly):
                part = loc['class'].replace('-', ' ').lower()
                p_weight = part_weights.get(loc['class'], 1)

                intersect = d_poly.intersection(l_poly)
                area = round(intersect.area, 2) if intersect.geom_type == 'Polygon' else 0.0

                max_area = max(d_poly.area, l_poly.area)
                if max_area > 0:
                    scaled_area = 1 + (area / max_area)
                else:
                    scaled_area = 1

                score = d_weight * p_weight * scaled_area
                total_score += score

                prefix = ''
                if side.lower() == 'left':
                    prefix = 'left '
                elif side.lower() == 'right':
                    prefix = 'right '

                description = (f"{dmg['class']} on {prefix}{part} "
                               f"(Damage confidence: {dmg['confidence']:.2f}, "
                               f"Part confidence: {loc['confidence']:.2f}, "
                               f"Area: {area} px², "
                               f"Scaled Area: {scaled_area:.2f})")

                damage_info.append(description)

                if area > 0:
                    draw.polygon(intersect.exterior.coords, fill=(255, 0, 0, 120))

                # Add the damaged part to the list (with prefix if needed)
                damaged_part = f"{prefix}{part}"
                if damaged_part not in damaged_parts:
                    damaged_parts.append(damaged_part)

    print("Damaged Parts:", damaged_parts)  # Print the damaged parts on terminal

    max_possible = 5 * 5 * len(part_weights)
    normalized_score = (total_score / max_possible) * 10 if max_possible else 0
    health_rating = round(10 - normalized_score, 2)

    final_img = Image.alpha_composite(img, overlay).convert("RGB")
    processed_path = os.path.join(app.config['PROCESSED_FOLDER'], os.path.basename(file_path))
    final_img.save(processed_path, "JPEG")

    result_image_url = url_for('static', filename=f'processed/{os.path.basename(processed_path)}')
    return result_image_url, damage_info, health_rating, damaged_parts


if __name__ == '__main__':
    app.run(debug=True)
